/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  ActiveTab,
  ActiveTool,
  BoundaryCondition,
  CadModelPreset,
  FeaResults,
  Material,
  OptimizationState,
  SimpParameters,
} from './types';
import { MATERIALS } from './data/materials';
import { CAD_PRESETS, INITIAL_CONDITIONS } from './data/models';
import { Header } from './components/Header';
import { SecondaryNav } from './components/SecondaryNav';
import { Toolbar } from './components/Toolbar';
import { LeftPanel } from './components/LeftPanel';
import { RightPanel } from './components/RightPanel';
import { CadViewport } from './components/CadViewport';
import { Footer } from './components/Footer';
import { Modals } from './components/Modals';

export default function App() {
  // Navigation & Tools
  const [activeTab, setActiveTab] = useState<ActiveTab>('optimizacion');
  const [activeTool, setActiveTool] = useState<ActiveTool>('seleccionar');

  // CAD Models & Preset
  const [models, setModels] = useState<CadModelPreset[]>(CAD_PRESETS);
  const [currentModel, setCurrentModel] = useState<CadModelPreset>(CAD_PRESETS[0]);
  const [isModelVisible, setIsModelVisible] = useState(true);

  // Material Selection
  const [selectedMaterial, setSelectedMaterial] = useState<Material>(MATERIALS[0]);

  // Boundary Conditions
  const [boundaryConditions, setBoundaryConditions] = useState<BoundaryCondition[]>(INITIAL_CONDITIONS);
  const [editingCondition, setEditingCondition] = useState<BoundaryCondition | null>(null);

  // SIMP Topology Optimization Parameters
  const [simpParams, setSimpParams] = useState<SimpParameters>({
    volfrac: 0.35,
    penalization: 3.0,
    filterRadius: 2.5,
    tolerance: 0.001,
    maxIterations: 100,
  });

  // Optimization Runtime State
  const initialMass = (currentModel.volumeCm3 * selectedMaterial.density) / 1000;
  const [optimizationState, setOptimizationState] = useState<OptimizationState>({
    isRunning: false,
    isPaused: false,
    currentIteration: 0,
    totalIterations: 100,
    currentCompliance: 148.5,
    currentVolume: 1.0,
    convergenceDelta: 0.015,
    initialMassKg: initialMass,
    currentMassKg: initialMass,
    complianceHistory: [148.5],
    volumeHistory: [1.0],
  });

  // FEA Analysis Results
  const [feaResults, setFeaResults] = useState<FeaResults>({
    maxVonMisesMpa: 342.4,
    minSafetyFactor: 1.47,
    maxDisplacementMm: 0.421,
    modalFreqHz: 428,
    strainEnergyJ: 1.84,
    meshQualityPercent: 98.4,
  });

  // Viewport & Mesh toggles
  const [showMesh, setShowMesh] = useState(false);
  const [showSection, setShowSection] = useState(false);
  const [meshElementSize, setMeshElementSize] = useState(1.8);
  const [isRemeshing, setIsRemeshing] = useState(false);
  const [deformationScale, setDeformationScale] = useState(1);
  const [coords, setCoords] = useState({ x: 124.5, y: 45.2, z: 0.0 });

  // Camera preset triggers
  const [resetViewTrigger, setResetViewTrigger] = useState(0);
  const [selectedViewTrigger, setSelectedViewTrigger] = useState<{
    view: 'iso' | 'top' | 'front' | 'right';
    count: number;
  }>({ view: 'iso', count: 0 });

  // Modals
  const [showImport, setShowImport] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  // Undo / Redo history
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Recalculate masses when material or model changes
  useEffect(() => {
    const newMass = (currentModel.volumeCm3 * selectedMaterial.density) / 1000;
    setOptimizationState((prev) => ({
      ...prev,
      initialMassKg: parseFloat(newMass.toFixed(2)),
      currentMassKg: parseFloat((newMass * (prev.currentIteration > 0 ? prev.currentVolume : 1)).toFixed(2)),
    }));
  }, [selectedMaterial, currentModel]);

  // SIMP Iterative Simulation Timer Loop
  const timerRef = useRef<number | null>(null);

  const startOptimization = () => {
    setOptimizationState((prev) => ({
      ...prev,
      isRunning: true,
      isPaused: false,
    }));
  };

  const pauseOptimization = () => {
    setOptimizationState((prev) => ({
      ...prev,
      isRunning: false,
      isPaused: true,
    }));
  };

  const resetOptimization = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    const baseMass = (currentModel.volumeCm3 * selectedMaterial.density) / 1000;
    setOptimizationState({
      isRunning: false,
      isPaused: false,
      currentIteration: 0,
      totalIterations: simpParams.maxIterations,
      currentCompliance: 148.5,
      currentVolume: 1.0,
      convergenceDelta: 0.015,
      initialMassKg: parseFloat(baseMass.toFixed(2)),
      currentMassKg: parseFloat(baseMass.toFixed(2)),
      complianceHistory: [148.5],
      volumeHistory: [1.0],
    });
  };

  // Run iterations smoothly
  useEffect(() => {
    if (optimizationState.isRunning) {
      timerRef.current = window.setInterval(() => {
        setOptimizationState((prev) => {
          if (prev.currentIteration >= prev.totalIterations) {
            if (timerRef.current) clearInterval(timerRef.current);
            return { ...prev, isRunning: false, isPaused: false };
          }

          const nextIter = prev.currentIteration + 1;
          const ratio = nextIter / prev.totalIterations;

          // Target volume fraction exponential decay
          const targetVol = simpParams.volfrac;
          const newVol = 1.0 - (1.0 - targetVol) * Math.pow(ratio, 0.8);
          const newMass = prev.initialMassKg * newVol;

          // Compliance decreases and converges
          const newCompliance = 148.5 - (148.5 - 41.2) * Math.pow(ratio, 0.65) + (Math.random() - 0.5) * 0.4;
          const delta = Math.abs(0.015 * (1 - ratio));

          return {
            ...prev,
            currentIteration: nextIter,
            currentVolume: parseFloat(newVol.toFixed(3)),
            currentMassKg: parseFloat(newMass.toFixed(2)),
            currentCompliance: parseFloat(newCompliance.toFixed(2)),
            convergenceDelta: parseFloat(delta.toFixed(4)),
            complianceHistory: [...prev.complianceHistory, newCompliance],
            volumeHistory: [...prev.volumeHistory, newVol],
          };
        });
      }, 90);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [optimizationState.isRunning, simpParams.volfrac, simpParams.maxIterations]);

  // Remesh Domain Action
  const handleRemesh = () => {
    setIsRemeshing(true);
    setTimeout(() => {
      setIsRemeshing(false);
      setShowMesh(true);
    }, 700);
  };

  // Toggle boundary condition
  const handleToggleCondition = (id: string) => {
    setBoundaryConditions((prev) =>
      prev.map((c) => (c.id === id ? { ...c, active: !c.active } : c))
    );
  };

  // Save edited condition
  const handleSaveCondition = (updated: BoundaryCondition) => {
    setBoundaryConditions((prev) =>
      prev.map((c) => (c.id === updated.id ? updated : c))
    );
  };

  // Handle custom file upload
  const handleCustomFileUpload = (file: File) => {
    const newPreset: CadModelPreset = {
      id: `custom_${Date.now()}`,
      filename: file.name,
      displayName: file.name.replace(/\.[^/.]+$/, '').toUpperCase(),
      faces: 28,
      edges: 42,
      solids: 1,
      volumeCm3: 480.0,
      elementsTet4: 195400,
      nodes: 41200,
    };
    setModels((prev) => [newPreset, ...prev]);
    setCurrentModel(newPreset);
  };

  // Undo / Redo helpers
  const handleUndo = () => {
    if (optimizationState.currentIteration > 0) {
      setOptimizationState((prev) => ({
        ...prev,
        currentIteration: Math.max(0, prev.currentIteration - 5),
      }));
    }
  };

  const handleRedo = () => {
    if (optimizationState.currentIteration < optimizationState.totalIterations) {
      setOptimizationState((prev) => ({
        ...prev,
        currentIteration: Math.min(prev.totalIterations, prev.currentIteration + 5),
      }));
    }
  };

  return (
    <div className="min-h-screen bg-viewport-bg text-on-surface font-sans select-none flex flex-col">
      {/* 1. TOP FIXED HEADER */}
      <Header
        onOpenImport={() => setShowImport(true)}
        onOpenExport={() => setShowExport(true)}
        onOpenHelp={() => setShowHelp(true)}
        onResetView={() => setResetViewTrigger((c) => c + 1)}
        onToggleMesh={() => setShowMesh((m) => !m)}
        showMesh={showMesh}
        onSelectView={(view) =>
          setSelectedViewTrigger((prev) => ({ view, count: prev.count + 1 }))
        }
      />

      {/* 2. SECONDARY MODE NAV TABS */}
      <div className="fixed top-[76px] left-0 right-0 z-40">
        <SecondaryNav activeTab={activeTab} onChangeTab={setActiveTab} />
        {/* 3. CAD TOOLBAR */}
        <Toolbar
          activeTool={activeTool}
          onSelectTool={setActiveTool}
          showMesh={showMesh}
          onToggleMesh={() => setShowMesh((m) => !m)}
          showSection={showSection}
          onToggleSection={() => setShowSection((s) => !s)}
          onUndo={handleUndo}
          onRedo={handleRedo}
        />
      </div>

      {/* 4. MAIN ENGINEERING STAGE */}
      <div className="pt-[146px] pb-7 flex-1 w-full flex flex-col bg-viewport-bg">
        <div className="w-full flex-1 flex flex-col xl:flex-row gap-space-sm p-space-sm bg-viewport-bg min-h-[calc(100vh-8.5rem)]">
          {/* LEFT PANEL: CAD Tree & Gmsh Mesher */}
          <LeftPanel
            currentModel={currentModel}
            models={models}
            onSelectModel={setCurrentModel}
            boundaryConditions={boundaryConditions}
            onToggleCondition={handleToggleCondition}
            onEditCondition={setEditingCondition}
            isModelVisible={isModelVisible}
            onToggleModelVisibility={() => setIsModelVisible(!isModelVisible)}
            onOpenImport={() => setShowImport(true)}
            meshElementSize={meshElementSize}
            onChangeMeshSize={setMeshElementSize}
            onRemesh={handleRemesh}
            isRemeshing={isRemeshing}
          />

          {/* CENTRAL 3D CAD VIEWPORT */}
          <CadViewport
            activeTab={activeTab}
            activeTool={activeTool}
            selectedMaterial={selectedMaterial}
            optimizationState={optimizationState}
            boundaryConditions={boundaryConditions}
            showMesh={showMesh}
            showSection={showSection}
            isModelVisible={isModelVisible}
            deformationScale={deformationScale}
            onUpdateCoords={setCoords}
            resetViewTrigger={resetViewTrigger}
            selectedViewTrigger={selectedViewTrigger}
          />

          {/* RIGHT PANEL: Materials, SIMP Parameters, and FEA Results */}
          <RightPanel
            activeTab={activeTab}
            materials={MATERIALS}
            selectedMaterial={selectedMaterial}
            onSelectMaterial={setSelectedMaterial}
            simpParams={simpParams}
            onChangeSimpParams={setSimpParams}
            optimizationState={optimizationState}
            onStartOptimization={startOptimization}
            onPauseOptimization={pauseOptimization}
            onResetOptimization={resetOptimization}
            feaResults={feaResults}
            deformationScale={deformationScale}
            onChangeDeformationScale={setDeformationScale}
            onExportReport={() => setShowExport(true)}
          />
        </div>
      </div>

      {/* 5. BOTTOM FIXED STATUS BAR */}
      <Footer
        coords={coords}
        elementsCount={Math.round(currentModel.elementsTet4 * (1.8 / meshElementSize))}
        nodesCount={Math.round(currentModel.nodes * (1.8 / meshElementSize))}
      />

      {/* 6. MODALS (IMPORT, EXPORT, HELP, EDIT) */}
      <Modals
        showImport={showImport}
        onCloseImport={() => setShowImport(false)}
        models={models}
        currentModel={currentModel}
        onSelectModel={setCurrentModel}
        onCustomFileUpload={handleCustomFileUpload}
        showExport={showExport}
        onCloseExport={() => setShowExport(false)}
        selectedMaterial={selectedMaterial}
        optimizationState={optimizationState}
        showHelp={showHelp}
        onCloseHelp={() => setShowHelp(false)}
        editingCondition={editingCondition}
        onCloseEditCondition={() => setEditingCondition(null)}
        onSaveCondition={handleSaveCondition}
      />
    </div>
  );
}
