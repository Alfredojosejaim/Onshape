---
name: Precision Engineering Dark Mode
colors:
  surface: '#10131c'
  surface-dim: '#10131c'
  surface-bright: '#363943'
  surface-container-lowest: '#0b0e17'
  surface-container-low: '#181b24'
  surface-container: '#1c1f29'
  surface-container-high: '#272a33'
  surface-container-highest: '#32343e'
  on-surface: '#e0e2ef'
  on-surface-variant: '#bec8d2'
  inverse-surface: '#e0e2ef'
  inverse-on-surface: '#2d303a'
  outline: '#88929b'
  outline-variant: '#3e4850'
  surface-tint: '#89ceff'
  primary: '#89ceff'
  on-primary: '#00344d'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#006591'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#d88a00'
  on-tertiary-container: '#4a2c00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#10131c'
  on-background: '#e0e2ef'
  surface-variant: '#32343e'
  viewport-bg: '#0f1117'
  surface-panel: '#181b24'
  surface-elevated: '#1f2430'
  border-subtle: '#2e3646'
  fea-stress-critical: '#ef4444'
  fea-stress-yield: '#f59e0b'
  fea-stress-optimal: '#10b981'
  text-primary: '#f1f5f9'
  text-secondary: '#94a3b8'
  text-muted: '#64748b'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: -0.01em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
  space-2xl: 1.5rem
  panel-tree-indent: 0.75rem
  toolbar-gap: 0.25rem
  inspector-row-gap: 0.375rem
---

## Brand & Style

This design system targets structural engineers, aerospace dynamicists, and mechanical product designers operating in high-density, mission-critical environments. The visual character balances cold, mathematical precision with ergonomic comfort during extended sessions. 

The aesthetic marries **Technical Functionalism** with **Modern Industrial Minimalism**:
- Surfaces are layered in deep, desaturated slate and zinc tones to reduce eye strain under prolonged screen exposure while ensuring the hardware-accelerated 3D viewport remains the visual centerpiece.
- Crisp, vibrant cyan indicators guide the eye toward active constraints, vector gizmos, and selection states, preventing tool hunting across dense toolbars.
- Alert and stress states borrow directly from finite element analysis (FEA) thermal spectra—amber warnings and vivid crimson yields—providing immediate, intuitive hazard comprehension.
- Micro-interactions favor sharp responsiveness (sub-150ms durations), tactile feedback, and crisp 1px structural framing over soft organic blurs.

## Colors

The palette establishes strict hierarchical separation between structural canvas boundaries, panel chrome, and computational feedback.

### Surface Architecture
- **Viewport Canvas (`#0f1117`)**: The deepest shade, dedicated exclusively to the 3D rendering context (VTK / WebGL). It maximizes contrast against high-polygon wireframes and illuminated volumetric meshes.
- **Base Panel Surface (`#181b24`)**: The docking foundation for tool palettes, tree views, and telemetry graphs.
- **Elevated Surfaces (`#1f2430`)**: Applied to inspectors, popover coordinate pickers, dropdown menus, and modal dialogs.
- **Structural Dividers (`#2e3646`)**: Crisp 1px perimeter definition ensuring visual segregation without excessive contrast noise.

### Functional Accents
- **Primary Cyber Cyan (`#0ea5e9` & `#38bdf8`)**: Primary action buttons, active viewport gizmos, selected feature tree nodes, and highlighted spatial dimensions.
- **FEA & Simulation Metrics**: Critical stress and failure markers utilize crimson (`#ef4444`), transitional yield uses amber (`#f59e0b`), and acceptable displacement thresholds register in muted emerald (`#10b981`).

## Typography

Typography prioritizes high-density vertical rhythm and spatial efficiency:

- **Inter** handles narrative copy, hierarchical tree labels, modal headers, and primary contextual prompts. Its clean geometric sans curves remain legible even at compact 11px and 12px scales.
- **JetBrains Mono** is mandatory for all numerical readouts, coordinate matrices (X, Y, Z coordinates), scalar parameters, simulation time-steps, and engineering units. Tabular figures prevent layout jitter during live value scrubs and iterative convergence routines.
- Letter spacing is tightened slightly across larger labels and opened subtly on micro labels (10px–11px) to prevent ink-trap blur on anti-aliased desktop displays.

## Layout & Spacing

This design system uses a strict 4px sub-grid with an 8px macro rhythm designed for docked multi-pane workstation software:

- **Workspace Layout**: A flexible 3-pane docking environment. The left pane defaults to 280px (collapsible) for feature trees, assembly hierarchies, and constraint history. The right pane defaults to 320px for parameter inspectors, material assigners, and simulation meshes. The central area operates as an infinite, high-performance viewport.
- **Density Over Spacing**: Unlike consumer web interfaces, margins are tightly compressed. Gap scales use `space-xs` (4px) and `space-sm` (6px) within toolbar clusters and field rows to maximize functional data-per-pixel.
- **Form Factor Adaptability**: On multi-monitor setups, side panels detach into floating windows. On constrained laptop displays (<= 1440px), panels automatically switch to narrow icon-only docking ribbons that slide open on hover or key-binding invocation.

## Elevation & Depth

To avoid visual muddiness across computational graphics, elevation is achieved primarily through **Tonal Layering** and **Crisp Structural Borders**, with soft ambient occlusion applied only to floating overlays.

- **Level 0 (Canvas Base)**: The 3D viewport canvas. Flat, raw render space with no inner shadows or border trims.
- **Level 1 (Docked Containers)**: Feature trees, tool ribbons, status footers. Background: `#181b24`, bounded by a 1px solid border (`#2e3646`). No dropshadows.
- **Level 2 (Active Cards & Cell Focus)**: Inspector groups and tree selections. Background: `#1f2430` with subtle border highlighting (`#38bdf8` at 25% opacity when focused).
- **Level 3 (Floating Toolbars & Context Menus)**: Viewport-floating navigation gizmos and right-click radial or linear menus. Background: `#1f2430`, border: 1px `#2e3646`, elevated with a directional shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.55), 0 2px 6px -1px rgba(0, 0, 0, 0.4)`.
- **Level 4 (Simulation Overlays & Modals)**: Critical warning dialogs and configuration sheets. Enhanced dropshadow: `0 20px 32px -8px rgba(0, 0, 0, 0.75)`.

## Shapes

The design system enforces a compact, disciplined corner radius (`roundedness: 1`):

- **Default UI Elements**: Buttons, input boxes, tree selection pills, and badge indicators use `0.25rem` (4px) radii. This creates modern ergonomics without wasting rectangular alignment space.
- **Popovers, Dropdowns & Floating Palettes**: Use `0.5rem` (8px) radii (`rounded-lg`) to distinctively detach floating controls from the rigid linear architecture of docked side panels.
- **Viewport Navigation HUDs**: Coordinate compasses and view-cube anchors use 2px subtle chamfers or 4px radii, emphasizing an engineered, mechanical instrument look.

## Components

### Action Buttons
- **Primary**: Solid `#0ea5e9` with bold `#0f1117` text. On hover: `#38bdf8`. Subtle 1px inset top border highlight (`rgba(255, 255, 255, 0.2)`).
- **Secondary / Tool**: Surface `#1f2430`, border 1px solid `#2e3646`, text `#f1f5f9`. On hover: border transitions to `#38bdf8`, background shifts to `#262d3d`.
- **Icon-Only Viewport Buttons**: Transparent background, 28x28px box, centered 16px iconography. Active tool states apply solid `#0ea5e9` with 15% opacity tint and a 1px `#0ea5e9` outline.

### Numeric Scrubbers & Dimension Inputs
- Dual-mode input fields featuring fixed or draggable axis labels (e.g., `X:`, `Y:`, `Z:`, `deg:`).
- Monospaced numerical values set in JetBrains Mono (`label-md`). Hovering over the label reveals a horizontal scrub cursor.
- Focused state applies a continuous 1px `#38bdf8` border with a 2px `#0ea5e9` glow ring (`rgba(14, 165, 233, 0.25)`).

### Tree Hierarchy & Assembly Panels
- Nested items indent by `panel-tree-indent` (12px) per level, connected via muted 1px guide lines (`#2e3646`).
- Left-aligned visibility toggle (eye icon) and suppression toggle.
- Selected node: background `#0ea5e9` at 15% opacity, text `#38bdf8`, with an accent indicator (2px solid `#38bdf8`) on the left border.

### Simulation Progress Indicators & Telemetry Bars
- Track height: 4px for ambient process bars; 16px for detailed solver status displays.
- Track background: `#181b24` with 1px border `#2e3646`.
- Value fill: Gradient fill transitioning from `#0ea5e9` to `#38bdf8`. If solver convergence warns of plasticity or strain limits, the gradient dynamically transitions to amber (`#f59e0b`) or crimson (`#ef4444`).

### Properties Inspector Cards
- Collapsible section headers with chevron indicators, set in `headline-sm` with text color `#94a3b8`.
- Form layouts pair labels on the left (`body-sm`, `#64748b`) with right-aligned numeric inputs (`label-md`, `#f1f5f9`) using clean tabular alignment.